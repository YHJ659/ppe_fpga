
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [1:0] axis_block_sigs;
wire [12:0] inst_idle_sigs;
wire [9:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~read_input_U0.in_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~write_output_U0.out_stream_TDATA_blk_n;

assign inst_idle_sigs[0] = read_input_U0.ap_idle;
assign inst_block_sigs[0] = (read_input_U0.ap_done & ~read_input_U0.ap_continue) | ~read_input_U0.grp_read_input_Pipeline_VITIS_LOOP_40_2_fu_68.strm_input24_blk_n;
assign inst_idle_sigs[1] = conv1x1_stream_U0.ap_idle;
assign inst_block_sigs[1] = (conv1x1_stream_U0.ap_done & ~conv1x1_stream_U0.ap_continue) | ~conv1x1_stream_U0.grp_conv1x1_stream_Pipeline_VITIS_LOOP_90_2_fu_40.strm_input24_blk_n | ~conv1x1_stream_U0.grp_conv1x1_stream_Pipeline_VITIS_LOOP_95_3_fu_46.strm_cv1_out25_blk_n;
assign inst_idle_sigs[2] = split_stream_128_to_64x4_U0.ap_idle;
assign inst_block_sigs[2] = (split_stream_128_to_64x4_U0.ap_done & ~split_stream_128_to_64x4_U0.ap_continue) | ~split_stream_128_to_64x4_U0.grp_split_stream_128_to_64x4_Pipeline_VITIS_LOOP_178_2_fu_46.strm_cv1_out25_blk_n | ~split_stream_128_to_64x4_U0.grp_split_stream_128_to_64x4_Pipeline_VITIS_LOOP_182_3_fu_54.strm_cv1_out25_blk_n | ~split_stream_128_to_64x4_U0.grp_split_stream_128_to_64x4_Pipeline_VITIS_LOOP_178_2_fu_46.strm_bypass26_blk_n | ~split_stream_128_to_64x4_U0.grp_split_stream_128_to_64x4_Pipeline_VITIS_LOOP_182_3_fu_54.strm_bn1_in29_blk_n | ~split_stream_128_to_64x4_U0.grp_split_stream_128_to_64x4_Pipeline_VITIS_LOOP_182_3_fu_54.strm_bn1_direct27_blk_n | ~split_stream_128_to_64x4_U0.grp_split_stream_128_to_64x4_Pipeline_VITIS_LOOP_182_3_fu_54.strm_bn1_to_add28_blk_n;
assign inst_idle_sigs[3] = conv3x3_stream_U0.ap_idle;
assign inst_block_sigs[3] = (conv3x3_stream_U0.ap_done & ~conv3x3_stream_U0.ap_continue) | ~conv3x3_stream_U0.grp_conv3x3_stream_Pipeline_VITIS_LOOP_127_3_fu_2102.strm_bn1_in29_blk_n | ~conv3x3_stream_U0.grp_conv3x3_stream_Pipeline_VITIS_LOOP_127_3_fu_2102.strm_bn1_out30_blk_n;
assign inst_idle_sigs[4] = duplicate_stream_64_U0.ap_idle;
assign inst_block_sigs[4] = (duplicate_stream_64_U0.ap_done & ~duplicate_stream_64_U0.ap_continue) | ~duplicate_stream_64_U0.strm_bn1_out30_blk_n | ~duplicate_stream_64_U0.strm_bn1_out_to_conv31_blk_n | ~duplicate_stream_64_U0.strm_bn1_out_to_concat32_blk_n;
assign inst_idle_sigs[5] = conv3x3_stream_1_U0.ap_idle;
assign inst_block_sigs[5] = (conv3x3_stream_1_U0.ap_done & ~conv3x3_stream_1_U0.ap_continue) | ~conv3x3_stream_1_U0.grp_conv3x3_stream_1_Pipeline_VITIS_LOOP_127_3_fu_2102.strm_bn1_out_to_conv31_blk_n | ~conv3x3_stream_1_U0.grp_conv3x3_stream_1_Pipeline_VITIS_LOOP_127_3_fu_2102.strm_bn2_conv_out33_blk_n;
assign inst_idle_sigs[6] = add_stream_64_U0.ap_idle;
assign inst_block_sigs[6] = (add_stream_64_U0.ap_done & ~add_stream_64_U0.ap_continue) | ~add_stream_64_U0.strm_bn2_conv_out33_blk_n | ~add_stream_64_U0.strm_bn1_to_add28_blk_n | ~add_stream_64_U0.strm_bn2_out34_blk_n;
assign inst_idle_sigs[7] = concat_stream_64x4_to_256_U0.ap_idle;
assign inst_block_sigs[7] = (concat_stream_64x4_to_256_U0.ap_done & ~concat_stream_64x4_to_256_U0.ap_continue) | ~concat_stream_64x4_to_256_U0.grp_concat_stream_64x4_to_256_Pipeline_VITIS_LOOP_216_2_fu_50.strm_bypass26_blk_n | ~concat_stream_64x4_to_256_U0.grp_concat_stream_64x4_to_256_Pipeline_VITIS_LOOP_220_3_fu_58.strm_bn1_direct27_blk_n | ~concat_stream_64x4_to_256_U0.grp_concat_stream_64x4_to_256_Pipeline_VITIS_LOOP_224_4_fu_66.strm_bn1_out_to_concat32_blk_n | ~concat_stream_64x4_to_256_U0.grp_concat_stream_64x4_to_256_Pipeline_VITIS_LOOP_228_5_fu_74.strm_bn2_out34_blk_n | ~concat_stream_64x4_to_256_U0.grp_concat_stream_64x4_to_256_Pipeline_VITIS_LOOP_224_4_fu_66.strm_concat_out35_blk_n | ~concat_stream_64x4_to_256_U0.grp_concat_stream_64x4_to_256_Pipeline_VITIS_LOOP_216_2_fu_50.strm_concat_out35_blk_n | ~concat_stream_64x4_to_256_U0.grp_concat_stream_64x4_to_256_Pipeline_VITIS_LOOP_220_3_fu_58.strm_concat_out35_blk_n | ~concat_stream_64x4_to_256_U0.grp_concat_stream_64x4_to_256_Pipeline_VITIS_LOOP_228_5_fu_74.strm_concat_out35_blk_n;
assign inst_idle_sigs[8] = conv1x1_stream_2_U0.ap_idle;
assign inst_block_sigs[8] = (conv1x1_stream_2_U0.ap_done & ~conv1x1_stream_2_U0.ap_continue) | ~conv1x1_stream_2_U0.grp_conv1x1_stream_2_Pipeline_VITIS_LOOP_90_2_fu_40.strm_concat_out35_blk_n | ~conv1x1_stream_2_U0.grp_conv1x1_stream_2_Pipeline_VITIS_LOOP_95_3_fu_46.strm_cv2_out36_blk_n;
assign inst_idle_sigs[9] = write_output_U0.ap_idle;
assign inst_block_sigs[9] = (write_output_U0.ap_done & ~write_output_U0.ap_continue) | ~write_output_U0.strm_cv2_out36_blk_n;

assign inst_idle_sigs[10] = 1'b0;
assign inst_idle_sigs[11] = read_input_U0.ap_idle;
assign inst_idle_sigs[12] = write_output_U0.ap_idle;

model6_c2f_accel_hls_deadlock_idx0_monitor model6_c2f_accel_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
