// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmodel6_c2f_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XModel6_c2f_accel_CfgInitialize(XModel6_c2f_accel *InstancePtr, XModel6_c2f_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_bus_BaseAddress = ConfigPtr->Ctrl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XModel6_c2f_accel_Start(XModel6_c2f_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel6_c2f_accel_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_AP_CTRL) & 0x80;
    XModel6_c2f_accel_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XModel6_c2f_accel_IsDone(XModel6_c2f_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel6_c2f_accel_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XModel6_c2f_accel_IsIdle(XModel6_c2f_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel6_c2f_accel_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XModel6_c2f_accel_IsReady(XModel6_c2f_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XModel6_c2f_accel_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XModel6_c2f_accel_EnableAutoRestart(XModel6_c2f_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel6_c2f_accel_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_AP_CTRL, 0x80);
}

void XModel6_c2f_accel_DisableAutoRestart(XModel6_c2f_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel6_c2f_accel_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_AP_CTRL, 0);
}

void XModel6_c2f_accel_InterruptGlobalEnable(XModel6_c2f_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel6_c2f_accel_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_GIE, 1);
}

void XModel6_c2f_accel_InterruptGlobalDisable(XModel6_c2f_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel6_c2f_accel_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_GIE, 0);
}

void XModel6_c2f_accel_InterruptEnable(XModel6_c2f_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XModel6_c2f_accel_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_IER);
    XModel6_c2f_accel_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_IER, Register | Mask);
}

void XModel6_c2f_accel_InterruptDisable(XModel6_c2f_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XModel6_c2f_accel_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_IER);
    XModel6_c2f_accel_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_IER, Register & (~Mask));
}

void XModel6_c2f_accel_InterruptClear(XModel6_c2f_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XModel6_c2f_accel_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_ISR, Mask);
}

u32 XModel6_c2f_accel_InterruptGetEnabled(XModel6_c2f_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XModel6_c2f_accel_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_IER);
}

u32 XModel6_c2f_accel_InterruptGetStatus(XModel6_c2f_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XModel6_c2f_accel_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XMODEL6_C2F_ACCEL_CTRL_BUS_ADDR_ISR);
}

