// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmodel6_c2f_accel.h"

extern XModel6_c2f_accel_Config XModel6_c2f_accel_ConfigTable[];

XModel6_c2f_accel_Config *XModel6_c2f_accel_LookupConfig(u16 DeviceId) {
	XModel6_c2f_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMODEL6_C2F_ACCEL_NUM_INSTANCES; Index++) {
		if (XModel6_c2f_accel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XModel6_c2f_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XModel6_c2f_accel_Initialize(XModel6_c2f_accel *InstancePtr, u16 DeviceId) {
	XModel6_c2f_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XModel6_c2f_accel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XModel6_c2f_accel_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

