// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XMODEL6_C2F_ACCEL_H
#define XMODEL6_C2F_ACCEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmodel6_c2f_accel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Ctrl_bus_BaseAddress;
} XModel6_c2f_accel_Config;
#endif

typedef struct {
    u64 Ctrl_bus_BaseAddress;
    u32 IsReady;
} XModel6_c2f_accel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XModel6_c2f_accel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XModel6_c2f_accel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XModel6_c2f_accel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XModel6_c2f_accel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XModel6_c2f_accel_Initialize(XModel6_c2f_accel *InstancePtr, u16 DeviceId);
XModel6_c2f_accel_Config* XModel6_c2f_accel_LookupConfig(u16 DeviceId);
int XModel6_c2f_accel_CfgInitialize(XModel6_c2f_accel *InstancePtr, XModel6_c2f_accel_Config *ConfigPtr);
#else
int XModel6_c2f_accel_Initialize(XModel6_c2f_accel *InstancePtr, const char* InstanceName);
int XModel6_c2f_accel_Release(XModel6_c2f_accel *InstancePtr);
#endif

void XModel6_c2f_accel_Start(XModel6_c2f_accel *InstancePtr);
u32 XModel6_c2f_accel_IsDone(XModel6_c2f_accel *InstancePtr);
u32 XModel6_c2f_accel_IsIdle(XModel6_c2f_accel *InstancePtr);
u32 XModel6_c2f_accel_IsReady(XModel6_c2f_accel *InstancePtr);
void XModel6_c2f_accel_EnableAutoRestart(XModel6_c2f_accel *InstancePtr);
void XModel6_c2f_accel_DisableAutoRestart(XModel6_c2f_accel *InstancePtr);


void XModel6_c2f_accel_InterruptGlobalEnable(XModel6_c2f_accel *InstancePtr);
void XModel6_c2f_accel_InterruptGlobalDisable(XModel6_c2f_accel *InstancePtr);
void XModel6_c2f_accel_InterruptEnable(XModel6_c2f_accel *InstancePtr, u32 Mask);
void XModel6_c2f_accel_InterruptDisable(XModel6_c2f_accel *InstancePtr, u32 Mask);
void XModel6_c2f_accel_InterruptClear(XModel6_c2f_accel *InstancePtr, u32 Mask);
u32 XModel6_c2f_accel_InterruptGetEnabled(XModel6_c2f_accel *InstancePtr);
u32 XModel6_c2f_accel_InterruptGetStatus(XModel6_c2f_accel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
