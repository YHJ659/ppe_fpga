
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [4:0] axis_block_sigs;
wire [4:0] inst_idle_sigs;
wire [0:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~grp_buffer01_fu_118.y0_s_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_buffer01_fu_118.y1_s_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_buffer2_fu_128.y2_s_TDATA_blk_n;
assign axis_block_sigs[3] = ~grp_combine_fu_135.grp_combine_Pipeline_COMBINE_MAIN_fu_80.y3_s_TDATA_blk_n;
assign axis_block_sigs[4] = ~grp_combine_fu_135.grp_combine_Pipeline_COMBINE_MAIN_fu_80.out_s_TDATA_blk_n;

assign inst_block_sigs[0] = 1'b0;

assign inst_idle_sigs[0] = 1'b0;
assign inst_idle_sigs[1] = grp_buffer01_fu_118.ap_idle;
assign inst_idle_sigs[2] = grp_buffer2_fu_128.ap_idle;
assign inst_idle_sigs[3] = grp_combine_fu_135.ap_idle;
assign inst_idle_sigs[4] = grp_combine_fu_135.grp_combine_Pipeline_COMBINE_MAIN_fu_80.ap_idle;

concat_channel_stream_hls_deadlock_idx0_monitor concat_channel_stream_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
