
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [16:0] axis_block_sigs;
wire [10:0] inst_idle_sigs;
wire [0:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~grp_step1_fu_62.y1_s_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_step1_fu_62.conv_in_s_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_bottleneck_router_Pipeline_VITIS_LOOP_43_1_fu_72.bn_out_s_TDATA_blk_n;
assign axis_block_sigs[3] = ~grp_bottleneck_router_Pipeline_VITIS_LOOP_43_1_fu_72.conv_in_s_TDATA_blk_n;
assign axis_block_sigs[4] = ~grp_step3_4_fu_80.bn_out_s_TDATA_blk_n;
assign axis_block_sigs[5] = ~grp_step3_4_fu_80.res_fx_s_TDATA_blk_n;
assign axis_block_sigs[6] = ~grp_step3_4_fu_80.grp_step3_4_Pipeline_VITIS_LOOP_55_2_fu_88.res_x_s_TDATA_blk_n;
assign axis_block_sigs[7] = ~grp_step5_fu_92.res_out_s_TDATA_blk_n;
assign axis_block_sigs[8] = ~grp_step5_fu_92.y2_out_s_TDATA_blk_n;
assign axis_block_sigs[9] = ~grp_step6_fu_102.conv_in_s_TDATA_blk_n;
assign axis_block_sigs[10] = ~grp_bottleneck_router_Pipeline_VITIS_LOOP_88_1_fu_110.bn_out_s_TDATA_blk_n;
assign axis_block_sigs[11] = ~grp_bottleneck_router_Pipeline_VITIS_LOOP_88_1_fu_110.conv_in_s_TDATA_blk_n;
assign axis_block_sigs[12] = ~grp_step8_9_fu_118.bn_out_s_TDATA_blk_n;
assign axis_block_sigs[13] = ~grp_step8_9_fu_118.res_fx_s_TDATA_blk_n;
assign axis_block_sigs[14] = ~grp_step8_9_fu_118.grp_step8_9_Pipeline_VITIS_LOOP_100_2_fu_88.res_x_s_TDATA_blk_n;
assign axis_block_sigs[15] = ~grp_bottleneck_router_Pipeline_VITIS_LOOP_109_1_fu_130.res_out_s_TDATA_blk_n;
assign axis_block_sigs[16] = ~grp_bottleneck_router_Pipeline_VITIS_LOOP_109_1_fu_130.y3_out_s_TDATA_blk_n;

assign inst_block_sigs[0] = 1'b0;

assign inst_idle_sigs[0] = 1'b0;
assign inst_idle_sigs[1] = grp_step1_fu_62.ap_idle;
assign inst_idle_sigs[2] = grp_bottleneck_router_Pipeline_VITIS_LOOP_43_1_fu_72.ap_idle;
assign inst_idle_sigs[3] = grp_step3_4_fu_80.ap_idle;
assign inst_idle_sigs[4] = grp_step3_4_fu_80.grp_step3_4_Pipeline_VITIS_LOOP_55_2_fu_88.ap_idle;
assign inst_idle_sigs[5] = grp_step5_fu_92.ap_idle;
assign inst_idle_sigs[6] = grp_step6_fu_102.ap_idle;
assign inst_idle_sigs[7] = grp_bottleneck_router_Pipeline_VITIS_LOOP_88_1_fu_110.ap_idle;
assign inst_idle_sigs[8] = grp_step8_9_fu_118.ap_idle;
assign inst_idle_sigs[9] = grp_step8_9_fu_118.grp_step8_9_Pipeline_VITIS_LOOP_100_2_fu_88.ap_idle;
assign inst_idle_sigs[10] = grp_bottleneck_router_Pipeline_VITIS_LOOP_109_1_fu_130.ap_idle;

bottleneck_router_hls_deadlock_idx0_monitor bottleneck_router_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
