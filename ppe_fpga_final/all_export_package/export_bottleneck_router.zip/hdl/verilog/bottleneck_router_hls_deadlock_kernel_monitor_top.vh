
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [15:0] axis_block_sigs;
wire [5:0] inst_idle_sigs;
wire [0:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~y1_s_TDATA_blk_n;
assign axis_block_sigs[1] = ~res_out_s_TDATA_blk_n;
assign axis_block_sigs[2] = ~conv_in_s_TDATA_blk_n;
assign axis_block_sigs[3] = ~res_x_s_TDATA_blk_n;
assign axis_block_sigs[4] = ~res_fx_s_TDATA_blk_n;
assign axis_block_sigs[5] = ~y2_out_s_TDATA_blk_n;
assign axis_block_sigs[6] = ~grp_bottleneck_router_Pipeline_STEP1_DRAIN_REST_fu_4961.bn_out_s_TDATA_blk_n;
assign axis_block_sigs[7] = ~grp_bottleneck_router_Pipeline_STEP2_DRAIN_REST_fu_4998.bn_out_s_TDATA_blk_n;
assign axis_block_sigs[8] = ~grp_bottleneck_router_Pipeline_STEP2_DRAIN_REST_fu_4998.res_fx_s_TDATA_blk_n;
assign axis_block_sigs[9] = ~grp_bottleneck_router_Pipeline_STEP2_DRAIN_REST_fu_4998.res_x_s_TDATA_blk_n;
assign axis_block_sigs[10] = ~grp_bottleneck_router_Pipeline_STEP6_DRAIN_REST_fu_5039.bn_out_s_TDATA_blk_n;
assign axis_block_sigs[11] = ~grp_bottleneck_router_Pipeline_STEP7_DRAIN_REST_fu_5067.bn_out_s_TDATA_blk_n;
assign axis_block_sigs[12] = ~grp_bottleneck_router_Pipeline_STEP7_DRAIN_REST_fu_5067.res_fx_s_TDATA_blk_n;
assign axis_block_sigs[13] = ~grp_bottleneck_router_Pipeline_STEP7_DRAIN_REST_fu_5067.res_x_s_TDATA_blk_n;
assign axis_block_sigs[14] = ~grp_bottleneck_router_Pipeline_STEP10_fu_5090.res_out_s_TDATA_blk_n;
assign axis_block_sigs[15] = ~grp_bottleneck_router_Pipeline_STEP10_fu_5090.y3_out_s_TDATA_blk_n;

assign inst_block_sigs[0] = 1'b0;

assign inst_idle_sigs[0] = 1'b0;
assign inst_idle_sigs[1] = grp_bottleneck_router_Pipeline_STEP1_DRAIN_REST_fu_4961.ap_idle;
assign inst_idle_sigs[2] = grp_bottleneck_router_Pipeline_STEP2_DRAIN_REST_fu_4998.ap_idle;
assign inst_idle_sigs[3] = grp_bottleneck_router_Pipeline_STEP6_DRAIN_REST_fu_5039.ap_idle;
assign inst_idle_sigs[4] = grp_bottleneck_router_Pipeline_STEP7_DRAIN_REST_fu_5067.ap_idle;
assign inst_idle_sigs[5] = grp_bottleneck_router_Pipeline_STEP10_fu_5090.ap_idle;

bottleneck_router_hls_deadlock_idx0_monitor bottleneck_router_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
