`timescale 1 ns / 1 ps

module bottleneck_router_hls_deadlock_idx0_monitor ( // for module bottleneck_router_bottleneck_router_inst
    input wire clock,
    input wire reset,
    input wire [16:0] axis_block_sigs,
    input wire [10:0] inst_idle_sigs,
    input wire [0:0] inst_block_sigs,
    output wire block
);

// signal declare
reg monitor_find_block;
wire idx1_block;
wire idx2_block;
wire idx3_block;
wire idx7_block;
wire idx8_block;
wire idx5_block;
wire idx10_block;
wire idx6_block;
wire sub_parallel_block;
wire all_sub_parallel_has_block;
wire all_sub_single_has_block;
wire cur_axis_has_block;
wire seq_is_axis_block;

assign block = monitor_find_block;
assign idx6_block = axis_block_sigs[9];
assign sub_parallel_block = 1'b0 | ((idx3_block & (axis_block_sigs[4] | axis_block_sigs[5] | axis_block_sigs[6])) & ((idx5_block | inst_idle_sigs[5]))) | ((idx5_block & (axis_block_sigs[7] | axis_block_sigs[8])) & ((idx3_block | inst_idle_sigs[3])));
assign all_sub_parallel_has_block = sub_parallel_block;
assign all_sub_single_has_block = 1'b0 | (idx1_block & (axis_block_sigs[0] | axis_block_sigs[1])) | (idx2_block & (axis_block_sigs[2] | axis_block_sigs[3])) | (idx7_block & (axis_block_sigs[10] | axis_block_sigs[11])) | (idx8_block & (axis_block_sigs[12] | axis_block_sigs[13] | axis_block_sigs[14])) | (idx10_block & (axis_block_sigs[15] | axis_block_sigs[16])) | (idx6_block & (axis_block_sigs[9]));
assign cur_axis_has_block = 1'b0;
assign seq_is_axis_block = all_sub_parallel_has_block | all_sub_single_has_block | cur_axis_has_block;

always @(posedge clock) begin
    if (reset == 1'b1)
        monitor_find_block <= 1'b0;
    else if (seq_is_axis_block == 1'b1)
        monitor_find_block <= 1'b1;
    else
        monitor_find_block <= 1'b0;
end


// instant sub module
 bottleneck_router_hls_deadlock_idx1_monitor bottleneck_router_hls_deadlock_idx1_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx1_block)
);

 bottleneck_router_hls_deadlock_idx2_monitor bottleneck_router_hls_deadlock_idx2_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx2_block)
);

 bottleneck_router_hls_deadlock_idx3_monitor bottleneck_router_hls_deadlock_idx3_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx3_block)
);

 bottleneck_router_hls_deadlock_idx7_monitor bottleneck_router_hls_deadlock_idx7_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx7_block)
);

 bottleneck_router_hls_deadlock_idx8_monitor bottleneck_router_hls_deadlock_idx8_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx8_block)
);

 bottleneck_router_hls_deadlock_idx5_monitor bottleneck_router_hls_deadlock_idx5_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx5_block)
);

 bottleneck_router_hls_deadlock_idx10_monitor bottleneck_router_hls_deadlock_idx10_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx10_block)
);

endmodule
