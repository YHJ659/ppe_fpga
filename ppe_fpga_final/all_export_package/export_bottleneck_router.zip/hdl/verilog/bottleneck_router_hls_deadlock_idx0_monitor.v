`timescale 1 ns / 1 ps

module bottleneck_router_hls_deadlock_idx0_monitor ( // for module bottleneck_router_bottleneck_router_inst
    input wire clock,
    input wire reset,
    input wire [14:0] axis_block_sigs,
    input wire [6:0] inst_idle_sigs,
    input wire [0:0] inst_block_sigs,
    output wire block
);

// signal declare
reg monitor_find_block;
wire idx4_block;
wire idx1_block;
wire idx6_block;
wire idx3_block;
wire idx2_block;
wire idx5_block;
wire sub_parallel_block;
wire all_sub_parallel_has_block;
wire all_sub_single_has_block;
wire cur_axis_has_block;
wire seq_is_axis_block;

assign block = monitor_find_block;
assign idx3_block = axis_block_sigs[9];
assign idx2_block = axis_block_sigs[8];
assign idx5_block = axis_block_sigs[12];
assign all_sub_parallel_has_block = 1'b0;
assign all_sub_single_has_block = 1'b0 | (idx4_block & (axis_block_sigs[10] | axis_block_sigs[11])) | (idx1_block & (axis_block_sigs[6] | axis_block_sigs[7])) | (idx6_block & (axis_block_sigs[13] | axis_block_sigs[14])) | (idx3_block & (axis_block_sigs[9])) | (idx2_block & (axis_block_sigs[8])) | (idx5_block & (axis_block_sigs[12]));
assign cur_axis_has_block = 1'b0 | axis_block_sigs[0] | axis_block_sigs[1] | axis_block_sigs[2] | axis_block_sigs[3] | axis_block_sigs[4] | axis_block_sigs[5];
assign seq_is_axis_block = all_sub_parallel_has_block | all_sub_single_has_block | cur_axis_has_block;

always @(posedge clock) begin
    if (reset == 1'b1)
        monitor_find_block <= 1'b0;
    else if (seq_is_axis_block == 1'b1)
        monitor_find_block <= 1'b1;
    else
        monitor_find_block <= 1'b0;
end


// instant sub module
 bottleneck_router_hls_deadlock_idx4_monitor bottleneck_router_hls_deadlock_idx4_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx4_block)
);

 bottleneck_router_hls_deadlock_idx1_monitor bottleneck_router_hls_deadlock_idx1_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx1_block)
);

 bottleneck_router_hls_deadlock_idx6_monitor bottleneck_router_hls_deadlock_idx6_monitor_U (
    .clock(clock),
    .reset(reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(idx6_block)
);

endmodule
