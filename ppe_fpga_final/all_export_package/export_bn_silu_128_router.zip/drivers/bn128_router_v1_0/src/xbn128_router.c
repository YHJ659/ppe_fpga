// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xbn128_router.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XBn128_router_CfgInitialize(XBn128_router *InstancePtr, XBn128_router_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XBn128_router_Start(XBn128_router *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBn128_router_ReadReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XBn128_router_WriteReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XBn128_router_IsDone(XBn128_router *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBn128_router_ReadReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XBn128_router_IsIdle(XBn128_router *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBn128_router_ReadReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XBn128_router_IsReady(XBn128_router *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBn128_router_ReadReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XBn128_router_EnableAutoRestart(XBn128_router *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBn128_router_WriteReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XBn128_router_DisableAutoRestart(XBn128_router *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBn128_router_WriteReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_AP_CTRL, 0);
}

void XBn128_router_InterruptGlobalEnable(XBn128_router *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBn128_router_WriteReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_GIE, 1);
}

void XBn128_router_InterruptGlobalDisable(XBn128_router *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBn128_router_WriteReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_GIE, 0);
}

void XBn128_router_InterruptEnable(XBn128_router *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBn128_router_ReadReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_IER);
    XBn128_router_WriteReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_IER, Register | Mask);
}

void XBn128_router_InterruptDisable(XBn128_router *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBn128_router_ReadReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_IER);
    XBn128_router_WriteReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XBn128_router_InterruptClear(XBn128_router *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBn128_router_WriteReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_ISR, Mask);
}

u32 XBn128_router_InterruptGetEnabled(XBn128_router *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBn128_router_ReadReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_IER);
}

u32 XBn128_router_InterruptGetStatus(XBn128_router *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBn128_router_ReadReg(InstancePtr->Control_BaseAddress, XBN128_ROUTER_CONTROL_ADDR_ISR);
}

