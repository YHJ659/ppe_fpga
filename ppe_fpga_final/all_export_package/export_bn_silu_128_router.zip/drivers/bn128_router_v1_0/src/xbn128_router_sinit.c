// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xbn128_router.h"

extern XBn128_router_Config XBn128_router_ConfigTable[];

XBn128_router_Config *XBn128_router_LookupConfig(u16 DeviceId) {
	XBn128_router_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XBN128_ROUTER_NUM_INSTANCES; Index++) {
		if (XBn128_router_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XBn128_router_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XBn128_router_Initialize(XBn128_router *InstancePtr, u16 DeviceId) {
	XBn128_router_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XBn128_router_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XBn128_router_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

