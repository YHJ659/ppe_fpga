// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XBN128_ROUTER_H
#define XBN128_ROUTER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xbn128_router_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XBn128_router_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XBn128_router;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XBn128_router_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XBn128_router_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XBn128_router_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XBn128_router_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XBn128_router_Initialize(XBn128_router *InstancePtr, u16 DeviceId);
XBn128_router_Config* XBn128_router_LookupConfig(u16 DeviceId);
int XBn128_router_CfgInitialize(XBn128_router *InstancePtr, XBn128_router_Config *ConfigPtr);
#else
int XBn128_router_Initialize(XBn128_router *InstancePtr, const char* InstanceName);
int XBn128_router_Release(XBn128_router *InstancePtr);
#endif

void XBn128_router_Start(XBn128_router *InstancePtr);
u32 XBn128_router_IsDone(XBn128_router *InstancePtr);
u32 XBn128_router_IsIdle(XBn128_router *InstancePtr);
u32 XBn128_router_IsReady(XBn128_router *InstancePtr);
void XBn128_router_EnableAutoRestart(XBn128_router *InstancePtr);
void XBn128_router_DisableAutoRestart(XBn128_router *InstancePtr);


void XBn128_router_InterruptGlobalEnable(XBn128_router *InstancePtr);
void XBn128_router_InterruptGlobalDisable(XBn128_router *InstancePtr);
void XBn128_router_InterruptEnable(XBn128_router *InstancePtr, u32 Mask);
void XBn128_router_InterruptDisable(XBn128_router *InstancePtr, u32 Mask);
void XBn128_router_InterruptClear(XBn128_router *InstancePtr, u32 Mask);
u32 XBn128_router_InterruptGetEnabled(XBn128_router *InstancePtr);
u32 XBn128_router_InterruptGetStatus(XBn128_router *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
